package com.spring.web.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.web.model.ScoreVO;

//dao객체 빈 등록
@Repository
public class ScoreDAO implements IScoreDAO {
	//학생들의 점수 정보를 저장할 리스트 생성 (db대용)
	private List<ScoreVO> scoreList = new ArrayList<ScoreVO>();

	@Override
	public void insertScore(ScoreVO services) {
		//넘겨받은 점수를 db에 저장
		scoreList.add(services);
	}

	@Override
	public List<ScoreVO> selectAllScores() {
		//db에서 전체점수를 얻어오고 서비스에게 넘긴다
		return scoreList;
	}

	@Override
	public void deleteScores(int stuNum) {
		//넘겨받은 학번의 해당하는 학생정보를 삭제한다
		scoreList.remove(stuNum);
	}

	@Override
	public ScoreVO selectOne(int stuNum) {
		//넘겨받은 학번의 학생을 조회해서 서비스에게 해당 학생 정보를 리턴
		return scoreList.get(stuNum);
	}
}
