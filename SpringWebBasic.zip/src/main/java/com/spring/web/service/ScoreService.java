package com.spring.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.web.model.ScoreVO;
import com.spring.web.repository.IScoreDAO;

//서비스 객체 빈 등록
@Service
public class ScoreService implements IScoreService {
	//서비스 계층은 잡일을 하고 db관련 일은 dao계층에게 맡긴다 -> 서비스 객체와 dao객체는 의존관계
	//서비스 계층과 의존관계인 dao객체 자동 의존성 주입
	@Autowired
	private IScoreDAO dao;
	
	@Override
	public void insertScore(ScoreVO services) {
		//총점과 평균 계산
		services.calcData();
		//넘겨받은 점수를 dao에게 넘겨 db에 저장한다
		dao.insertScore(services);
	}

	@Override
	public List<ScoreVO> selectAllScores() {
		//dao에게 점수전체를 넘겨받고 컨트롤러에게 넘겨준다
		return dao.selectAllScores();
	}

	@Override
	public void deleteScores(int stuNum) {
		stuNum = stuNum - 1;
		//dao에게 삭제할 학생의 학번을 넘긴다
		dao.deleteScores(stuNum);
	}

	@Override
	public ScoreVO selectOne(int stuNum) {
		stuNum = stuNum - 1;
		//dao에게 조회할 학생 학번을 넘겨 학생 한명 정보얻고 컨트롤러에게 리턴
		ScoreVO stuVO = dao.selectOne(stuNum);
		return stuVO;
	}
}
