package com.spring.web;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

//com.spring.web 패키지안에 있고 @Controller로 지정이 되었기 때문에 자동으로 스프링 컨테이너에 빈으로 등록되어 있다
//HandlerMapping객체가 이런 controller객체를 검색해서 dispatcherServlet에게 알림 -> 
//dispatcherServlet은 handlerAdapter에게 HandlerMapping이 찾은 controller에서  사용자 요청에 부합하는 메소드 검색을 요청 ->
//handlerAdapter가 다시 controller로 와서 사용자 요청에 부합하는 메소드를 찾고 실행
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	//@RequestMapping(value = "/", method = RequestMethod.GET) : handlerAdapter가 /로 시작하고 get방식인 요청이 들어 오면 이 메소드를 찾는다
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		//session.setAtrribute()
		model.addAttribute("serverTime", formattedDate );
		
		//메소드실행 후 controller객체는 handlerAdapter객체에 ModelAndView 객체를 반환하고 hadlerAdapter는 이 객체를 dispatcher에게 반환한다
		//ModelAndView객체는 사용자 응답에 필요한 데이터 정보와 뷰정보(jsp파일)가 들어 있다
		return "home";
	}
	
}
