package com.spring.web.model;

public class BirthVO {
	private String year;
	private String month;
	private String day;
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		if(Integer.parseInt(month) < 10) month = 0 + month;
		this.month = month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		if(Integer.parseInt(day) < 10) day = 0 + day;
		this.day = day;
	}
	
	@Override
	public String toString() {
		return "BirthVO [year=" + year + ", month=" + month + ", day=" + day + "]";
	}
}
