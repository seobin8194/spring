package com.spring.web.model;

import java.util.List;

public class userVO {
	private String userid;
	private String userpw;
	private String username;
	private List<String> hobby;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpw() {
		return userpw;
	}
	public void setUserpw(String userpw) {
		this.userpw = userpw;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public List<String> getHobby() {
		return hobby;
	}
	public void setHobby(List<String> hobby) {
		this.hobby = hobby;
	}
	
	@Override
	public String toString() {
		return "userVO [userid=" + userid + ", userpw=" + userpw + ", username=" + username + ", hobby=" + hobby + "]";
	}	
}
