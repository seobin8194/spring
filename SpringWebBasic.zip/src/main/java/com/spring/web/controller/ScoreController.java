package com.spring.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.web.model.ScoreVO;
import com.spring.web.service.IScoreService;

@Controller
@RequestMapping("/score")
public class ScoreController {
	//컨트롤러는 요청흐름만 제어하고 짜잘한 처리는 서비스 계층에 맡긴다 -> 컨트롤러와 서비스 객체는 의존관계
	//컨트롤러와 서비스 계층 사이의 의존성 자동 주입을 위해 변수를 선언
	@Autowired
	private IScoreService service;
	
	//점수 등록화면을 열어주는 처리를 하는 요청 메서드
	@GetMapping("/register")
	public String register() {
		System.out.println("/score/register : get");
		return "score/write-form";
	}
	
	//점수 등록을 처리하는 요청 메서드
	@PostMapping("/register")
	public String register(ScoreVO scores) {
		System.out.println("/score/register : post");
		//System.out.println("param : " + scores);
		//사용자가 입력한 점수를 서비스에게 넘긴다
		service.insertScore(scores);
		return "score/write-result";
	}
	
	//점수 전체 조회를 처리하는 요청 메서드
	@GetMapping("/list")
	public void list(Model model) {
		System.out.println("/score/list : get");
		//서비스에게 점수전체를 넘겨받는다
		List<ScoreVO> list = service.selectAllScores();
		model.addAttribute("sList", list);
	}
	
	//점수삭제요청을 처리하는 요청 메서드
	@GetMapping("/delete")
	public String delete(@RequestParam("stuNum") int stuNum, RedirectAttributes ra) {
		System.out.println("삭제할 학번 : " + stuNum);
		/*문제: 삭제 처리완료 후에 list요청이 다시 컨트롤러로 들어갈 수 있도록 처리
		list요청이 다시 들어가서 list.jsp로 갔을때 삭제 이후 간것으로 판단되면 alert()로 삭제 메시지를 띄워라*/
		
		//학생 한명 정보 삭제하기 위해 해당 학번을 서비스에게 넘긴다
		service.deleteScores(stuNum);
		//삭제완료 메시지
		ra.addFlashAttribute("deleteMsg", "delSuccess");
		//list 재요청
		return "redirect:/score/list";	
	}
	
	//점수 개별조회 화면 열람요청 메서드
	@GetMapping("/search")
	public void search() {
		System.out.println("/score/search : get");
	}
	
	//점수개별조회 처리 요청 메서드
	@PostMapping("/selectOne")
	public String selectOne(@RequestParam("stuNum") int stuNum, Model model, RedirectAttributes ra) {
		//전체 학생 수 파악을 위함
		List<ScoreVO> list = service.selectAllScores();
		
		//입력한 학번이 전체 학생수보다 큰 경우
		if(stuNum > list.size()) {
			ra.addFlashAttribute("msg", "학생정보가 없습니다");
			return "redirect:/score/search";
		}else {
			//조회할 학생의 학번을 서비스에게 넘긴다
			ScoreVO stuVO = service.selectOne(stuNum);
			model.addAttribute("stuVO", stuVO);
			return "score/search-result";	
		}
	}
}
