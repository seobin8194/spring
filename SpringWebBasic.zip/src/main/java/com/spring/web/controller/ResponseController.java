package com.spring.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.web.model.userVO;

@Controller
@RequestMapping("/response")
public class ResponseController {
	@GetMapping("/res-ex01")
	public void resEx01() {}
	
	//1. Model객체를 사용하여 화면에 데이터 전송하기
	//요청받고 응답 페이지에 데이터를 넘기고 싶을때 (jsp에서 session과 같은 역할)
	//매개값으로 model객체를 받는다고 명시하면 handlerAdapter가 이 객체를 갖다줘서 사용자는 이 객체에 데이터를 담는다
	//controller객체가 handlerAdapter에게 view문자열을 리턴할때 model객체도 함께 리턴하여 dispatcher서블릿에게 전달되고 view페이지까지 전달된다
//	@GetMapping("/test")
//	public void test(@RequestParam("age") int age, Model model) {
//		//model에 데이터를 담는다
//		model.addAttribute("age", age);
//		model.addAttribute("nick", "멍멍이");
//	}
	
	//2. @ModelAttribute를 사용한 화면에 데이터 전송처리
	//@RequestParm + model.addAttribute
	//즉 요청시 전달한 데이터를 받는것과 동시에 model객체에 받은 데이터를 담고 응답 페이지로 전달
	@GetMapping("/test")
	public void test(@ModelAttribute("age") int age, Model model) {
		model.addAttribute("nick", "멍멍이");	
	}
	
	//3. ModelAndView 객체를 활용한 처리
	//이 객체를 이용하여 응답할 페이지와 전달할 데이터를 처리할 수 있다
	//rest환경에서 viewResolver를 사용못하는데 그때 많이 사용하는 객체
	@GetMapping("/test2")
	public ModelAndView test2() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("username", "김철수");
		//context root를 제외한 나머지 경로제시
		mv.setViewName("/response/test2");
		return mv;
	}
//	@GetMapping("/test2")
//	public ModelAndView test2() {
//		//보낼 데이터가 1개일때
//		return new ModelAndView("/response/test2", "username", "hong");
//	}
	
	////////////////////////////////////////////////////////////////////////////////
	//객체를 전달받아 응답 페이지에 전달하기
	@GetMapping("/res-ex02")
	public void resEx02() {}
	
	@PostMapping("/join")
	public String join(@ModelAttribute("user") userVO user) {
		//model.addAttribute("user", vo);
		return "response/test3";	
	}
	
	/////////////////////////////////////////////////////////////////////////////////
	//res-quiz
	@GetMapping("/res-quiz")
	public void resQuiz() {}
	
	//커맨드객체와 model객체를 이용하는 방법
	@PostMapping("/res-login")
	public String login(userVO vo, Model model) {
		String userid = vo.getUserid();
		String userpw = vo.getUserpw();
		
		model.addAttribute("userid", userid);
		model.addAttribute("userpw", userpw);
		
		if(userid.equals("kim1234") && userpw.equals("kkk1234")) {
			return "response/res-quiz-success";
		}else {
			return "response/res-quiz-fail";
		}
	}
	
	//@RequsetParm과 model객체를 이용하는 방법
//	@PostMapping("/res-login")
//	public String login(@RequestParam("userid") String userid, @RequestParam("userpw") String userpw, Model model) {
//		model.addAttribute("userid", userid);
//		model.addAttribute("userpw", userpw);
//		if(userid.equals("kim1234") && userpw.equals("kkk1234")) {
//			return "response/res-quiz-success";
//		}else {
//			return "response/res-quiz-fail";
//		}
//	}
	
	//@ModelAttribute를 이용하는 방법
//	@PostMapping("/res-login")
//	public String login(@ModelAttribute("userid") String userid, @ModelAttribute("userpw") String userpw) {
//		if(userid.equals("kim1234") && userpw.equals("kkk1234")) {
//			return "response/res-quiz-success";
//		}else {
//			return "response/res-quiz-fail";
//		}
//	}
	
	//////////////////////////////////////////////////////////////////////////////////////////
	//Redirect 처리
	@GetMapping("/login")
	public String login() {
		System.out.println("/login : get");
		return "response/res-redirect-form";
	}
	
	//redirect는 요청에 대한 응답 후 재요청하는 것
	//model객체는 request요청범위 안에서만 유효하므로 redirect시 화면에서 데이터를 사용할 수 없다
	//model안에 안에 있는 값을 재요청 url에 parmeter로 붙인다
	//->web/response/login?msg=""
//	@PostMapping("/login")
//	public String login(
//			@RequestParam("userid") String userid, 
//			@RequestParam("userpw") String userpw, 
//			@RequestParam("userpwChk") String userpwChk, 
//			Model model) 
//	{
//		System.out.println("/login : post");
//		System.out.println("id : "+ userid + "pw : " + userpw + "userpwChk" + userpwChk);
//		if(userid.equals("")) {
//			model.addAttribute("msg","아이디는 필수값");
//			//사용자에게 응답을 보내고 다시 폼을 보기위해 위 요청(/login : get")을 재요청
//			return "redirect:/response/login";
//		}
//		return "";	
//	}
	
	@PostMapping("/login")
	//RedirectAttributes : redirect때도 데이터를 보내고싶을때 사용하는 객체
	public String login(
			@RequestParam("userid") String userid, 
			@RequestParam("userpw") String userpw, 
			@RequestParam("userpwChk") String userpwChk, 
			RedirectAttributes ra) 
	{
		System.out.println("/login : post");
		System.out.println("id : "+ userid + "pw : " + userpw + "userpwChk" + userpwChk);
		if(userid.equals("")) {
			//addFlashAttribute로 담은 데이터는 일회용(redirect시 화면에서 새로고침하면 데이터 없어짐)
			ra.addFlashAttribute("msg", "아이디는 필수값이에요");
			return "redirect:/response/login";
		}else if(!userpw.equals(userpwChk)) {
			ra.addFlashAttribute("msg", "비밀번호 확인란을 확인하세요");
			return "redirect:/response/login";
		}
		return "";	
	}	
}
