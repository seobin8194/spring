package com.spring.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.web.model.BoardVO;
import com.spring.web.service.IBoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private IBoardService service;
	
	//글 작성 화면 요청
	@GetMapping("/write")
	public void write() {
		System.out.println("/board/write : get");
	}
	
	//작성된 글 등록 처리
	//작성된 글을 리스트에 등록한 후 /board/list.jsp파일로 글 목록을 보여달라는 요청이 자동으로 들어와야함
	@PostMapping("/write")
	public String write(BoardVO vo) {
		System.out.println("/board/write : post");
		service.insertArticle(vo);
		return "redirect:/board/list";	
	}
	
	//글목록 화면 요청
	//리스트에서 가져 온 글 목록을 list.jsp로 전달해서 브라우저에 글 목록 띄우기
	@GetMapping("/list")
	public void list(Model model) {
		System.out.println("/board/list : get");
		List<BoardVO> articles = service.getArticles();
		model.addAttribute("articles", articles);
	}
	
	//글 내용 상세보기 요청
	//리스트에서 글 번호에 해당하는 글 객체를 content.jsp로 넘겨라
	@GetMapping("/content")
	public void content(@ModelAttribute("boardNo") int boardNo, Model model) {
		System.out.println("/board/content?boardNo" + boardNo+ " : get");
		BoardVO article = service.getArticle(boardNo);
		model.addAttribute("article", article);
	}
	
	//글 수정하기 화면 요청
	@GetMapping("/modify")
	public void modify(@ModelAttribute("boardNo") int boardNo, Model model) {
		System.out.println("/board/modify?boardNo=" + boardNo + " : get");
		BoardVO article = service.getArticle(boardNo);
		model.addAttribute("article", article);
	}
	
	//글 수정 요청
	//수정처리 완료 후 방금 수정된 글의 상세보기 페이지로 이동
	@PostMapping("/modify")
	public String modify(@RequestParam("boardNo") int boardNo, BoardVO vo) {
		System.out.println("/board/modify?boardNo" + boardNo + " : post");
		service.updateArticle(vo, boardNo);
		return "redirect:/board/content?boardNo=" + boardNo;	
	}
	
	//글 삭제 요청
	@GetMapping("/delete")
	public String delete(@RequestParam("boardNo") int boardNo) {
		System.out.println("/board/delete?boardNo=" + boardNo + " : get");
		service.deleteArticle(boardNo);
		return "redirect:/board/list";
	}
}
