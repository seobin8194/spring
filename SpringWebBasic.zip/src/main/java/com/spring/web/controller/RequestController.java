package com.spring.web.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.web.model.userVO;

//자동으로 스프링 컨테이너에 해당 클래스의 빈을 등록하는 아노테이션
//빈을 등록해야 HandlerMapping이 이 클래스의 객체를 검색할 수 있을 것이다
@Controller
//컨트롤러 자체에 공통된 uri를 맵핑하면 메소드마다 /request를 작성안해도 된다
//HandlerMapping이 컨트롤러 찾을때 요청이 /request로 시작안하면 쳐다도 안본다
@RequestMapping("/request")
public class RequestController {
	public RequestController() {
		System.out.println("Request Controller 빈 등록");
	}
	
	//@RequestMapping은 어떤 uri로 이 메소드를 동작시킬것인가에 대한 설정
	@RequestMapping("/test")
	public String testCall() {
		System.out.println("/request/test 요청이 들어왔어요");
		return "test";	
	}
	
	//사용자가 /request/req 요청이 들어왔을때 views폴더 아래 request폴더에 req-ex01.jsp파일을 열도록 메서드를 구성해보세요
	@RequestMapping("/req")
	public String reqCall() {
		System.out.println("/request/req 요청이 들어왔어요");
		return "request/req-ex01";	
	}
	
	//get방식과 post방식 구분하지 않으면 두 요청 다 받는다
	//get요청만 받음
	//@RequestMapping(value="/request/basic01", method=RequestMethod.GET)
	//spring 4버전부터 생긴 아노테이션
	@GetMapping("/basic01")
	public String basicGet() {
		System.out.println("/request/basic01 요청이 들어옴 : get");
		return "request/req-ex01";
	}
	//post요청만 받음
	//@RequestMapping(value="/request/basic01", method=RequestMethod.POST)
	@PostMapping("/basic01")
	public String basicPost() {
		System.out.println("/request/basic01 요청이 들어옴 : post");
		return "request/req-ex01";
	}
	
	//컨트롤러의 요청 메소드를 void리턴 타입으로 지정
	//요청 uri(request/req-ex02)경로의 jsp파일을 찾는다
	//즉 dispatcher서블릿이 viewResolver에게 문자열로 요청 uri를 전달한다
	@GetMapping("/req-ex02")
	public void reqCall2() {
		System.out.println("/request/req-ex02 요청");
	}
	
	//////////////////////////////////////////////////////////////////////////////
	@GetMapping("/join")
	public void register() {
		System.out.println("/request/join : get");
	}
/*
	1. 전통적인 jsp/servlet 방식의 파라미터 읽기 처리 방법
	 - HttpServletRequest객체를 활용
	   handlerAdapter가 request 객체를 건네주면서 이 메소드를 실행한다
	@PostMapping("/join")
	public String register(HttpServletRequest request) {
		System.out.println("/request/join : post");
		System.out.println("id : " + request.getParameter("userid"));
		System.out.println("pw : " + request.getParameter("userpw"));
		System.out.println("name : " + request.getParameter("username"));
		System.out.println("hobby : " + Arrays.toString(request.getParameterValues("hobby")));
		return "request/join";
	}
*/
	
/*
	2. @RequestParam 아노테이션을 이용한 요청 파라미터 처리
	요구된 값을 안보내면 에러 -> required를 false로 지정하고 defaultValue를 지정하여 해결
	@PostMapping("/join")
	public void register(@RequestParam("userid") String id,
						 @RequestParam("userpw") String pw,
						 @RequestParam("username") String name,
						 @RequestParam(value="hobby", required = false, defaultValue = "no hobby") List<String> hobbys) {
		System.out.println("id : " + id);
		System.out.println("pw : " + pw);
		System.out.println("name : " + name);
		System.out.println("hobby : " + hobbys);
	}
*/
	
/*
	3. 커맨드 객체를 활용한 파라미터 처리
	   form의 name속성값과 vo클래스 변수명과 일치하면 가능
*/
	@PostMapping("/join")
	public void register(userVO vo) {
		System.out.println("id : " + vo.getUserid());
		System.out.println("pw : " + vo.getUserpw());
		System.out.println("name : " + vo.getUsername());
		System.out.println("hobby : " + vo.getHobby());	
	}
	
/////////////////////////////////////////////////////////////////////////////////////////////////
	//req-quiz정답
	@GetMapping("/quiz")
	public String quiz() {
		System.out.println("/requst/quiz : get");
		return "request/req-quiz";
	}
	@PostMapping("/quiz")
	public String quiz(userVO vo) {
		if(vo.getUserid().equals("abc1234") && vo.getUserpw().equals("aaa1111")) {
			return "request/login-success";
		}else {
			return "request/login-fail";
		}
	}
}
