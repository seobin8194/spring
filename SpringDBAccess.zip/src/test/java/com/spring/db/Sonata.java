package com.spring.db;

public class Sonata implements Car {

	@Override
	public void run() {
		System.out.println("소나타는 달립니다");
	}
}
