package com.spring.db;

public interface Calculator {
	int add(int n1, int n2);
}
