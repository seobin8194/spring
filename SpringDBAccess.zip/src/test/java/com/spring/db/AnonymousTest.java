package com.spring.db;

public class AnonymousTest {

	public static void main(String[] args) {
		Car s = new Sonata();
		s.run();
		
		//이 클래스안에서 계속 부를 수 있다
		Car t = new Car() {
			@Override
			public void run() {
				System.out.println("테슬라가 달립니다");
			}
		};
		t.run();
		
		//한번 실행하면 끝
		new Car() {
			@Override
			public void run() {
				System.out.println("포르쉐가 달립니다");	
			}
		}.run();
		
		//lambda식 적용 : 인터페이스안에 추상 메서드가 단 하나일때만 가능
		Car morning = () -> {
			System.out.println("모닝이 달립니다");
		};
		morning.run();
		
		System.out.println("========================================");
		
		//계산기 인터페이스와 람다식
		Calculator sharp = new Calculator() {
			@Override
			public int add(int n1, int n2) {
				System.out.println("샤프계산기의 덧셈");
				return n1 + n2;
			}
		};	
		System.out.println(sharp.add(10, 15));
		
		Calculator casio = (x, y) -> {
			System.out.println("카시오 계산기의 덧셈");
			return x + y;
		};
		System.out.println(casio.add(10, 13));
		
		Calculator xiaomi = (x, y) -> x + y;
		System.out.println(xiaomi.add(10,12));
	}
}
