package com.spring.db;

public interface Car {
	void run();
}
