package com.spring.db.mybatis.score.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.db.mybatis.score.model.ScoreVO;
import com.spring.db.mybatis.score.service.IScoreService;

//이름을 지정하지 않으면 클래스명으로 빈이 등록되고 이름을 지정하면 해당 이름으로 빈 등록함
@Controller("scoreController2")
@RequestMapping("/mybatis/score")
public class ScoreController {
	@Autowired
	//같은 타입의 빈이 존재할때 어떤 빈을 주입할지 명시
	@Qualifier("scoreService2")
	private IScoreService service;
	
	//점수 등록화면을 열어주는 처리를 하는 요청 메서드
	@GetMapping("/register")
	public String register() {
		System.out.println("/mybatis/score/register : get");
		return "score2/write-form";
	}
	
	//점수 등록을 처리하는 요청 메서드
	@PostMapping("/register")
	public String register(ScoreVO scores) {
		System.out.println("/mybatis/score/register : post");
		System.out.println(scores.toString());
		service.insertScore(scores);
		return "score2/write-result";
	}
	
	//점수 전체 조회를 처리하는 요청 메서드
	@GetMapping("/list")
	public String list(Model model) {
		System.out.println("/mybatis/score/list : get");
		List<ScoreVO> list = service.selectAllScores();
		model.addAttribute("sList", list);
		return "score2/list";
	}
	
	//점수삭제요청을 처리하는 요청 메서드
	@GetMapping("/delete")
	//parameter변수명과 매개변수 변수명과 일치하면 @RequestParam("stu_id")생략가능
	public String delete(@RequestParam("stu_id") int stu_id, RedirectAttributes ra) {
		System.out.println("삭제할 학번 : " + stu_id);
		service.deleteScores(stu_id);
		ra.addFlashAttribute("deleteMsg", "delSuccess");
		return "redirect:/mybatis/score/list";	
	}
	
	//점수 개별조회 화면 열람요청 메서드
	@GetMapping("/search")
	public String search() {
		System.out.println("/score/search : get");
		return "score2/search";
	}
	
	//점수개별조회 처리 요청 메서드
	@PostMapping("/selectOne")
	public String selectOne(@RequestParam("stu_id") int stu_id, Model model, RedirectAttributes ra) {
		ScoreVO vo = service.selectOne(stu_id);
		System.out.println("selectOne Result : " + vo);
		model.addAttribute("stuVO", vo);
		return "score2/search-result";	
	}
}
