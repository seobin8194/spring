package com.spring.db.jdbc.board.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spring.db.jdbc.board.model.BoardVO;

@Repository
public class BoardDAO implements IBoardDAO {
	//내부 클래스 선언
	class BoardMapper implements RowMapper<BoardVO> {
		@Override
		public BoardVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			BoardVO vo = new BoardVO();
			vo.setBoard_num(rs.getInt("board_num"));
			vo.setWriter(rs.getString("writer"));
			vo.setTitle(rs.getString("title"));
			vo.setContent(rs.getString("content"));
			return vo;
		}
	}
	
	@Autowired
	private JdbcTemplate template;

	@Override
	public void insertArticle(BoardVO vo) {
		String sql = "insert into board values (bid_seq.nextval,?,?,?)";
		template.update(sql, vo.getWriter(), vo.getTitle(), vo.getContent());	
	}

	@Override
	public List<BoardVO> getArticles() {
		String sql = "select * from board order by board_num desc";
		return template.query(sql, new BoardMapper());
	}

	@Override
	public BoardVO getArticle(int board_num) {
		String sql = "select * from board where board_num = ?";
		return template.queryForObject(sql, new BoardMapper(), board_num);
	}

	@Override
	public void deleteArticle(int board_num) {
		String sql = "delete from board where board_num = ?";
		template.update(sql, board_num);	
	}

	@Override
	public void updateArticle(BoardVO vo, int board_num) {
		String sql = "update board set writer = ?, title = ?, content = ? where board_num = ?";
		template.update(sql, vo.getWriter(), vo.getTitle(), vo.getContent(), board_num);
	}
}