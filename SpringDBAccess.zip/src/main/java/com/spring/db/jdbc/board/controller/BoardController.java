package com.spring.db.jdbc.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.db.jdbc.board.model.BoardVO;
import com.spring.db.jdbc.board.service.IBoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private IBoardService service;
	
	//글 작성 화면 요청
	@GetMapping("/write")
	public void write() {
		System.out.println("/board/write : get");
	}
	
	//작성된 글 등록 처리
	//작성된 글을 리스트에 등록한 후 /board/list.jsp파일로 글 목록을 보여달라는 요청이 자동으로 들어와야함
	@PostMapping("/write")
	public String write(BoardVO vo) {
		System.out.println("/board/write : post");
		service.insertArticle(vo);
		return "redirect:/board/list";	
	}
	
	//글목록 화면 요청
	//리스트에서 가져 온 글 목록을 list.jsp로 전달해서 브라우저에 글 목록 띄우기
	@GetMapping("/list")
	public void list(Model model) {
		System.out.println("/board/list : get");
		List<BoardVO> articles = service.getArticles();
		System.out.println("getArticles() 결과 : " + articles);
		model.addAttribute("articles", articles);
	}
	
	//글 내용 상세보기 요청
	//리스트에서 글 번호에 해당하는 글 객체를 content.jsp로 넘겨라
	@GetMapping("/content")
	public void content(@RequestParam("board_num") int board_num, Model model) {
		System.out.println("/board/content?board_num" + board_num+ " : get");
		BoardVO article = service.getArticle(board_num);
		model.addAttribute("article", article);
	}
	
	//글 수정하기 화면 요청
	@GetMapping("/modify")
	public void modify(@RequestParam("board_num") int board_num, Model model) {
		System.out.println("/board/modify?board_num=" + board_num + " : get");
		BoardVO article = service.getArticle(board_num);
		model.addAttribute("article", article);
	}
	
	//글 수정 요청
	//수정처리 완료 후 방금 수정된 글의 상세보기 페이지로 이동
	@PostMapping("/modify")
	public String modify(BoardVO vo) {
		System.out.println("/board/modify?board_num" + vo.getBoard_num() + " : post");
		service.updateArticle(vo);
		return "redirect:/board/content?board_num=" + vo.getBoard_num();	
	}
	
	//글 삭제 요청
	@GetMapping("/delete")
	public String delete(@RequestParam("board_num") int board_num) {
		System.out.println("/board/delete?board_num=" + board_num + " : get");
		service.deleteArticle(board_num);
		return "redirect:/board/list";
	}
	
	//게시글 검색 처리 요청
	/*
	 글 검색을 처리해서 화면에 응답
	 해당 키워드가 들어가 있는 글들을 모두 검색
	 데이터베이스에서 조회한 결과를 list.jsp에 있는 테이블을 재활용해서 뿌리기
	*/
	@GetMapping("/searchList")
	public String searchList(@RequestParam("keyword") String keyword, Model model) {
		System.out.println("/board/searchList : get");
		List<BoardVO> articles = service.getArticlesByKeyword(keyword);
		model.addAttribute("articles", articles);
		return "board/list";
	}
}
