package com.spring.db.jdbc.score.model;

public class ScoreVO {
	private int stu_id;
	private String stu_name;
	private int kor;
	private int math;
	private int eng;
	private int total;
	private double average;
	
	//총점. 평균을 구하는 메소드
	public void calcData(){
		this.total = this.kor + this.math + this.eng;
		this.average = this.total / 3.0;
	}

	public int getStu_id() {
		return stu_id;
	}

	public void setStu_id(int stu_id) {
		this.stu_id = stu_id;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	@Override
	public String toString() {
		return "ScoreVO [stu_id=" + stu_id + ", stu_name=" + stu_name + ", kor=" + kor + ", math=" + math + ", eng="
				+ eng + ", total=" + total + ", averaeg=" + average + "]";
	}
}
