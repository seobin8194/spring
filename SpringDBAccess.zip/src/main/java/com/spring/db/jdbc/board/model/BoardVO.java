package com.spring.db.jdbc.board.model;

public class BoardVO {
	private int board_num;
	private String writer;
	private String title;
	private String content;
	
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	@Override
	public String toString() {
		return "BoardVO [board_num=" + board_num + ", writer=" + writer + ", title=" + title + ", content=" + content
				+ "]";
	}
}
