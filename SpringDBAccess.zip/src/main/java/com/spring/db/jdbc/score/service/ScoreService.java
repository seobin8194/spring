package com.spring.db.jdbc.score.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.db.jdbc.score.model.ScoreVO;
import com.spring.db.jdbc.score.repository.IScoreDAO;

@Service
public class ScoreService implements IScoreService {
	@Autowired
	private IScoreDAO dao;
	
	@Override
	public void insertScore(ScoreVO scores) {
		//총점과 평균 계산
		scores.calcData();
		dao.insertScore(scores);
	}

	@Override
	public List<ScoreVO> selectAllScores() {
		return dao.selectAllScores();
	}

	@Override
	public void deleteScores(int stu_id) {
		dao.deleteScores(stu_id);
	}

	@Override
	public ScoreVO selectOne(int stu_id) {
		ScoreVO stuVO = dao.selectOne(stu_id);
		return stuVO;
	}
}
