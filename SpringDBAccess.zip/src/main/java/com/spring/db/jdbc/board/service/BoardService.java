package com.spring.db.jdbc.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.db.jdbc.board.model.BoardVO;
import com.spring.db.jdbc.board.repository.IBoardDAO;
import com.spring.db.jdbc.board.repository.IBoardMapper;

@Service
public class BoardService implements IBoardService {
	//mybatis를 이용한 sql처리
	@Autowired
	private IBoardMapper mapper;

	@Override
	public void insertArticle(BoardVO vo) {
		mapper.insertArticle(vo);
	}

	@Override
	public List<BoardVO> getArticles() {
		return mapper.getArticles();
	}

	@Override
	public BoardVO getArticle(int board_num) {
		return mapper.getArticle(board_num);
	}

	@Override
	public void deleteArticle(int board_num) {
		mapper.deleteArticle(board_num);
	}

	@Override
	public void updateArticle(BoardVO vo) {
		mapper.updateArticle(vo);
	}

	@Override
	public List<BoardVO> getArticlesByKeyword(String keyword) {
		keyword ="%" + keyword+ "%";
		return mapper.getArticlesByKeyword(keyword);
	}
	
}
